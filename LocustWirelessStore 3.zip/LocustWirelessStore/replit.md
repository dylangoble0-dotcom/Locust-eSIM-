# Overview

This is a modern eSIM marketplace application called **Locust Wireless** that offers affordable, no-contract mobile data plans. The platform focuses on budget-friendly 30-day+ plans without commitments. It integrates with the eSIM Access API to provide real-time package availability and automated eSIM provisioning. Users can browse cheap data plans, view package details, and complete purchases via email delivery of QR codes for eSIM activation.

**Key Value Proposition**: Cheap, reliable data plans without contracts - not travel-focused, but affordability-focused.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture

**Framework**: React 18 with TypeScript, using Vite as the build tool and development server.

**Routing**: Wouter for lightweight client-side routing with pages for Home, Plans, and 404 handling.

**UI Framework**: Shadcn UI component library built on Radix UI primitives with Tailwind CSS for styling. The design system uses the "new-york" style variant with a custom color scheme emphasizing a premium, modern aesthetic using Inter for body text and Space Grotesk for headings.

**State Management**: TanStack Query (React Query) for server state management with 5-minute stale times for package data caching, reducing unnecessary API calls.

**Form Handling**: React Hook Form with Zod for schema validation and type safety.

**Animations**: Framer Motion for micro-interactions and page transitions.

**Design Tokens**: CSS custom properties for theming with light/dark mode support, using HSL color space for flexible color manipulation.

## Backend Architecture

**Server Framework**: Express.js with TypeScript running on Node.js.

**Architecture Pattern**: Monolithic full-stack application with server-side rendering support via Vite middleware in development.

**API Design**: RESTful endpoints under `/api` prefix:
- `POST /api/packages` - Fetch available eSIM packages with optional filtering
- `POST /api/orders` - Create new order and provision eSIM
- Package caching implemented in-memory with 5-minute TTL to reduce external API calls

**Database Layer**: 
- Drizzle ORM with PostgreSQL dialect for type-safe database operations
- Connection pooling via Neon serverless driver with WebSocket support
- Schema-first approach with Zod integration for runtime validation

**Data Models**:
- `users` - User authentication (username/password)
- `orders` - Order records including eSIM provisioning details (orderNo, email, package info, ICCIDs, QR codes, status tracking)

**Middleware Stack**:
- JSON body parsing with raw body preservation for webhook verification
- Custom request logging with timestamp and duration tracking
- Static file serving for production builds

**Build Process**: 
- Dual build system: Vite for client bundle, esbuild for server bundle
- Server dependencies are selectively bundled (allowlist) to reduce cold start times
- Production build outputs to `dist/` with separate client (`dist/public`) and server bundles

## External Dependencies

**eSIM Provider**: eSIM Access API (api.esimaccess.com)
- HMAC-SHA256 signature authentication
- Package listing and order placement
- Real-time inventory management
- Automatic eSIM provisioning with QR code generation

**Database**: PostgreSQL via Neon Serverless
- WebSocket-based connection for serverless environments
- Connection string required via `DATABASE_URL` environment variable
- Database migrations managed through Drizzle Kit

**Development Tools**:
- Replit-specific plugins for development experience (cartographer, dev banner, runtime error overlay)
- Meta image plugin for Open Graph tag management on Replit deployments

**Production Infrastructure**:
- Designed for Replit deployment with domain detection
- Environment-based configuration (NODE_ENV)
- Session management ready (connect-pg-simple for PostgreSQL session store)

**API Integration Pattern**: 
The application acts as a proxy between users and the eSIM Access API, caching package data to improve performance while maintaining real-time order processing. Orders are stored locally for tracking while eSIM provisioning is handled by the external provider.