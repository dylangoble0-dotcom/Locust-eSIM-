import crypto from "crypto";

const API_BASE_URL = "https://api.esimaccess.com";

interface EsimApiConfig {
  accessCode: string;
  secretKey: string;
}

export interface PackageListRequest {
  locationCode?: string;
  type?: "BASE" | "TOPUP";
  packageCode?: string;
  slug?: string;
  iccid?: string;
}

export interface OrderProfileRequest {
  packageCode: string;
  quantity: number;
  email?: string;
}

interface ApiResponse<T> {
  success: boolean;
  errorCode: string | null;
  errorMsg: string | null;
  obj: T;
}

export class EsimAccessApi {
  private config: EsimApiConfig;

  constructor(config: EsimApiConfig) {
    this.config = config;
  }

  private generateSignature(timestamp: string, requestId: string, requestBody: string): string {
    const signStr = timestamp + requestId + this.config.accessCode + requestBody;
    return crypto.createHmac("sha256", this.config.secretKey).update(signStr).digest("hex").toLowerCase();
  }

  private async makeRequest<T>(endpoint: string, body: any = {}): Promise<ApiResponse<T>> {
    const timestamp = Date.now().toString();
    const requestId = crypto.randomUUID().replace(/-/g, "");
    const requestBody = JSON.stringify(body);
    const signature = this.generateSignature(timestamp, requestId, requestBody);

    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "RT-AccessCode": this.config.accessCode,
        "RT-Timestamp": timestamp,
        "RT-RequestID": requestId,
        "RT-Signature": signature,
      },
      body: requestBody,
    });

    if (!response.ok) {
      throw new Error(`eSIM API Error: ${response.status} ${response.statusText}`);
    }

    return await response.json();
  }

  async getPackageList(request: PackageListRequest = {}) {
    return this.makeRequest("/api/v1/open/package/list", request);
  }

  async orderProfiles(request: OrderProfileRequest) {
    return this.makeRequest("/api/v1/open/esim/order", request);
  }

  async queryBalance() {
    return this.makeRequest("/api/v1/open/balance/query", {});
  }

  async queryEsimProfile(iccid: string) {
    return this.makeRequest<EsimProfileInfo>("/api/v1/open/esim/query", { iccid });
  }
}

export interface EsimProfileInfo {
  iccid: string;
  status: string;
  activationDate?: string;
  expiryDate?: string;
  totalVolume?: number;
  usedVolume?: number;
  remainingVolume?: number;
}

export function createEsimApi(): EsimAccessApi {
  const accessCode = process.env.ESIM_ACCESS_CODE;
  const secretKey = process.env.ESIM_SECRET_KEY;

  if (!accessCode || !secretKey) {
    throw new Error("eSIM Access credentials not configured. Please set ESIM_ACCESS_CODE and ESIM_SECRET_KEY environment variables.");
  }

  return new EsimAccessApi({ accessCode, secretKey });
}
