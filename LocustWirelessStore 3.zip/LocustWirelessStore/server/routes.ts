import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { createEsimApi } from "./esim-api";
import { setupSession, setupAuthRoutes, requireAuth } from "./auth";
import { z } from "zod";
import { fromError } from "zod-validation-error";
import OpenAI from "openai";

interface PackageInfo {
  packageCode: string;
  name: string;
  price: number;
  retailPrice: number;
  volume: number;
  duration: number;
  durationUnit: string;
  speed: string;
}

let packageCache: Map<string, PackageInfo> = new Map();
let cacheExpiry = 0;
const CACHE_TTL = 5 * 60 * 1000; // 5 minutes

async function getPackageFromCache(packageCode: string): Promise<PackageInfo | null> {
  if (Date.now() > cacheExpiry || packageCache.size === 0) {
    try {
      const esimApi = createEsimApi();
      const result = await esimApi.getPackageList({ type: "BASE" });
      if (result.success && result.obj) {
        const packages = (result.obj as { packageList?: PackageInfo[] }).packageList || [];
        packageCache.clear();
        packages.forEach((pkg: PackageInfo) => {
          packageCache.set(pkg.packageCode, pkg);
        });
        cacheExpiry = Date.now() + CACHE_TTL;
      }
    } catch (error) {
      console.error("Failed to refresh package cache:", error);
    }
  }
  return packageCache.get(packageCode) || null;
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Setup session and auth routes
  setupSession(app);
  setupAuthRoutes(app);

  // Get user's orders (protected route)
  app.get('/api/my-orders', requireAuth, async (req: any, res) => {
    try {
      const userId = (req.session as any).userId;
      const orders = await storage.getOrdersByUserId(userId);
      res.json(orders);
    } catch (error) {
      console.error("Error fetching user orders:", error);
      res.status(500).json({ message: "Failed to fetch orders" });
    }
  });

  // Get all packages with optional filters
  app.post("/api/packages", async (req, res) => {
    try {
      const esimApi = createEsimApi();
      const result = await esimApi.getPackageList(req.body);
      
      if (!result.success) {
        return res.status(400).json({ 
          error: result.errorMsg || "Failed to fetch packages",
          errorCode: result.errorCode 
        });
      }
      
      res.json(result.obj);
    } catch (error: any) {
      console.error("Error fetching packages:", error);
      res.status(500).json({ 
        error: error.message || "Internal server error",
        details: error.toString()
      });
    }
  });

  // Create a new order - SERVER-SIDE PRICE VALIDATION
  app.post("/api/orders", async (req: any, res) => {
    try {
      const orderRequest = z.object({
        email: z.string().email(),
        packageCode: z.string(),
        quantity: z.number().min(1).default(1),
      }).parse(req.body);

      // SECURITY: Fetch package details from cache/API - never trust client price
      const packageInfo = await getPackageFromCache(orderRequest.packageCode);
      if (!packageInfo) {
        return res.status(400).json({ 
          error: "Invalid package code. Package not found." 
        });
      }

      // Use server-side verified price
      const serverPrice = packageInfo.price;
      const totalAmount = serverPrice * orderRequest.quantity;

      // Generate unique order number
      const orderNo = `LW-${Date.now()}-${Math.random().toString(36).substring(7).toUpperCase()}`;

      // Get user ID if authenticated
      const userId = (req.session as any)?.userId;

      // Create order in database with server-validated pricing and plan metadata
      const order = await storage.createOrder({
        orderNo,
        userId,
        email: orderRequest.email,
        packageCode: orderRequest.packageCode,
        packageName: packageInfo.name,
        price: serverPrice,
        quantity: orderRequest.quantity,
        totalAmount,
        status: "processing",
        planVolumeBytes: packageInfo.volume?.toString(),
        planDurationDays: packageInfo.durationUnit === "DAY" ? packageInfo.duration : (packageInfo.duration * 30),
        networkSpeed: packageInfo.speed,
      });

      // Call eSIM API to create profiles
      try {
        const esimApi = createEsimApi();
        const result = await esimApi.orderProfiles({
          packageCode: orderRequest.packageCode,
          quantity: orderRequest.quantity,
          email: orderRequest.email,
        });

        if (result.success && result.obj) {
          // Update order with eSIM details
          const esimResult = result.obj as { iccids?: string[]; qrCodes?: string[]; orderNo?: string };
          const updatedOrder = await storage.updateOrder(order.id, {
            status: "completed",
            iccids: esimResult.iccids || [],
            qrCodes: esimResult.qrCodes || [],
          });
          
          res.json(updatedOrder);
        } else {
          // Update order status to failed
          await storage.updateOrder(order.id, {
            status: "failed",
          });
          
          res.status(400).json({ 
            error: result.errorMsg || "Failed to create eSIM profiles",
            errorCode: result.errorCode,
            order
          });
        }
      } catch (esimError: any) {
        // Update order status to failed
        await storage.updateOrder(order.id, {
          status: "failed",
        });
        
        throw esimError;
      }

    } catch (error: any) {
      if (error instanceof z.ZodError) {
        const validationError = fromError(error);
        return res.status(400).json({ error: validationError.message });
      }
      
      console.error("Error creating order:", error);
      res.status(500).json({ 
        error: error.message || "Internal server error" 
      });
    }
  });

  // Get orders by email
  app.get("/api/orders/:email", async (req, res) => {
    try {
      const { email } = req.params;
      const orders = await storage.getOrdersByEmail(email);
      res.json(orders);
    } catch (error: any) {
      console.error("Error fetching orders:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Get order by order number
  app.get("/api/order/:orderNo", async (req, res) => {
    try {
      const { orderNo } = req.params;
      const order = await storage.getOrderByOrderNo(orderNo);
      
      if (!order) {
        return res.status(404).json({ error: "Order not found" });
      }
      
      res.json(order);
    } catch (error: any) {
      console.error("Error fetching order:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Check API balance
  app.get("/api/balance", async (req, res) => {
    try {
      const esimApi = createEsimApi();
      const result = await esimApi.queryBalance();
      
      if (!result.success) {
        return res.status(400).json({ 
          error: result.errorMsg || "Failed to query balance",
          errorCode: result.errorCode 
        });
      }
      
      res.json(result.obj);
    } catch (error: any) {
      console.error("Error querying balance:", error);
      res.status(500).json({ 
        error: error.message || "Internal server error" 
      });
    }
  });

  // AI Chat support endpoint
  app.post("/api/chat", async (req, res) => {
    try {
      const { messages } = req.body;
      
      if (!messages || !Array.isArray(messages)) {
        return res.status(400).json({ error: "Messages array required" });
      }

      const openai = new OpenAI({
        apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
        baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
      });

      const systemPrompt = `You are a friendly and helpful customer support assistant for Locust Wireless, a company that offers affordable, no-contract mobile data plans via eSIM technology.

Key information about Locust Wireless:
- We offer 30-day data plans ranging from 10GB to 50GB
- All plans are for US coverage only
- No contracts or commitments required
- eSIM delivery is instant via email with QR code
- Plans include hotspot capability
- Supports 4G LTE and 5G networks
- For billing or account issues, customers can email support@locustwireless.com

How eSIM works:
1. Customer purchases a plan
2. QR code is sent to their email instantly
3. Customer scans the QR code with their phone to install the eSIM
4. eSIM activates on first use

Be helpful, concise, and friendly. If you don't know something specific about their account, suggest they email support@locustwireless.com for personalized assistance.`;

      const response = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: systemPrompt },
          ...messages.map((m: { role: string; content: string }) => ({
            role: m.role as "user" | "assistant",
            content: m.content,
          })),
        ],
        max_tokens: 500,
        temperature: 0.7,
      });

      const assistantMessage = response.choices[0]?.message?.content || "I'm sorry, I couldn't generate a response. Please try again.";

      res.json({ message: assistantMessage });
    } catch (error: any) {
      console.error("Chat error:", error);
      res.status(500).json({ 
        error: "Failed to process chat request",
        message: error.message 
      });
    }
  });

  // Dashboard data endpoint (protected)
  app.get('/api/dashboard', requireAuth, async (req: any, res) => {
    try {
      const userId = (req.session as any).userId;
      const orders = await storage.getOrdersByUserId(userId);
      
      // Find active orders (completed orders with eSIM)
      const activeOrders = orders.filter(o => 
        o.status === 'completed' && o.iccids && (o.iccids as string[]).length > 0
      );
      
      // Get usage info for active eSIMs (if available)
      const esimUsage: Record<string, any> = {};
      
      for (const order of activeOrders) {
        const iccids = order.iccids as string[];
        for (const iccid of iccids) {
          try {
            const esimApi = createEsimApi();
            const result = await esimApi.queryEsimProfile(iccid);
            if (result.success && result.obj) {
              esimUsage[iccid] = result.obj;
            }
          } catch (err) {
            console.error(`Failed to get usage for ICCID ${iccid}:`, err);
          }
        }
      }
      
      res.json({
        orders,
        activeOrders,
        esimUsage,
      });
    } catch (error) {
      console.error("Error fetching dashboard data:", error);
      res.status(500).json({ message: "Failed to fetch dashboard data" });
    }
  });

  // Query eSIM profile/usage (protected)
  app.get('/api/esim/:iccid', requireAuth, async (req: any, res) => {
    try {
      const { iccid } = req.params;
      const esimApi = createEsimApi();
      const result = await esimApi.queryEsimProfile(iccid);
      
      if (!result.success) {
        return res.status(400).json({ 
          error: result.errorMsg || "Failed to query eSIM profile",
          errorCode: result.errorCode 
        });
      }
      
      res.json(result.obj);
    } catch (error: any) {
      console.error("Error querying eSIM profile:", error);
      res.status(500).json({ 
        error: error.message || "Internal server error" 
      });
    }
  });

  return httpServer;
}
