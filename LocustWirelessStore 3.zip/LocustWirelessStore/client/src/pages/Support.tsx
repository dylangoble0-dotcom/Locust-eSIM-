import { Navbar } from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useState, useRef, useEffect } from "react";
import { Send, Mail, MessageCircle, Loader2, Bot, User } from "lucide-react";
import { toast } from "sonner";
import { Toaster } from "sonner";
import { motion, AnimatePresence } from "framer-motion";

interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}

export default function Support() {
  const [activeTab, setActiveTab] = useState<"email" | "chat">("chat");
  
  // Email form state
  const [emailForm, setEmailForm] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  });
  const [isSendingEmail, setIsSendingEmail] = useState(false);

  // Chat state
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      role: "assistant",
      content: "Hi! I'm here to help you with any questions about Locust Wireless. How can I assist you today?",
    },
  ]);
  const [chatInput, setChatInput] = useState("");
  const [isChatLoading, setIsChatLoading] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatMessages]);

  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!emailForm.name || !emailForm.email || !emailForm.message) {
      toast.error("Please fill in all required fields");
      return;
    }

    setIsSendingEmail(true);
    
    // Simulate sending email (in production, this would call a backend endpoint)
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    toast.success("Message sent!", {
      description: "We'll get back to you at " + emailForm.email + " soon.",
    });
    
    setEmailForm({ name: "", email: "", subject: "", message: "" });
    setIsSendingEmail(false);
  };

  const handleChatSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || isChatLoading) return;

    const userMessage = chatInput.trim();
    setChatInput("");
    setChatMessages(prev => [...prev, { role: "user", content: userMessage }]);
    setIsChatLoading(true);

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [...chatMessages, { role: "user", content: userMessage }],
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to get response");
      }

      const data = await response.json();
      setChatMessages(prev => [...prev, { role: "assistant", content: data.message }]);
    } catch (error) {
      toast.error("Failed to get response. Please try again.");
      setChatMessages(prev => [...prev, { 
        role: "assistant", 
        content: "I'm sorry, I'm having trouble responding right now. Please try again or email us at support@locustwireless.com." 
      }]);
    } finally {
      setIsChatLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background font-sans">
      <Navbar />
      <Toaster position="top-center" richColors />

      <main className="pt-32 pb-20">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-display font-bold text-foreground mb-4">
              How Can We Help?
            </h1>
            <p className="text-muted-foreground text-lg">
              Chat with our assistant or send us a message. We're here to help!
            </p>
          </div>

          {/* Tab Switcher */}
          <div className="flex justify-center gap-4 mb-8">
            <Button
              variant={activeTab === "chat" ? "default" : "outline"}
              onClick={() => setActiveTab("chat")}
              className={`rounded-full px-6 ${activeTab === "chat" ? "bg-primary" : ""}`}
              data-testid="button-tab-chat"
            >
              <MessageCircle className="w-4 h-4 mr-2" />
              Chat with Us
            </Button>
            <Button
              variant={activeTab === "email" ? "default" : "outline"}
              onClick={() => setActiveTab("email")}
              className={`rounded-full px-6 ${activeTab === "email" ? "bg-primary" : ""}`}
              data-testid="button-tab-email"
            >
              <Mail className="w-4 h-4 mr-2" />
              Send Email
            </Button>
          </div>

          <AnimatePresence mode="wait">
            {activeTab === "chat" ? (
              <motion.div
                key="chat"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="bg-card rounded-2xl border border-border shadow-lg overflow-hidden"
              >
                {/* Chat Messages */}
                <div className="h-[400px] overflow-y-auto p-6 space-y-4">
                  {chatMessages.map((msg, i) => (
                    <div
                      key={i}
                      className={`flex gap-3 ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                    >
                      {msg.role === "assistant" && (
                        <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                          <Bot className="w-4 h-4 text-primary" />
                        </div>
                      )}
                      <div
                        className={`max-w-[80%] p-4 rounded-2xl ${
                          msg.role === "user"
                            ? "bg-primary text-primary-foreground"
                            : "bg-muted"
                        }`}
                        data-testid={`chat-message-${i}`}
                      >
                        <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                      </div>
                      {msg.role === "user" && (
                        <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center flex-shrink-0">
                          <User className="w-4 h-4 text-muted-foreground" />
                        </div>
                      )}
                    </div>
                  ))}
                  {isChatLoading && (
                    <div className="flex gap-3 justify-start">
                      <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
                        <Bot className="w-4 h-4 text-primary" />
                      </div>
                      <div className="bg-muted p-4 rounded-2xl">
                        <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />
                      </div>
                    </div>
                  )}
                  <div ref={chatEndRef} />
                </div>

                {/* Chat Input */}
                <form onSubmit={handleChatSubmit} className="border-t border-border p-4">
                  <div className="flex gap-3">
                    <Input
                      value={chatInput}
                      onChange={(e) => setChatInput(e.target.value)}
                      placeholder="Type your message..."
                      className="flex-1 rounded-full"
                      disabled={isChatLoading}
                      data-testid="input-chat"
                    />
                    <Button
                      type="submit"
                      disabled={!chatInput.trim() || isChatLoading}
                      className="rounded-full bg-primary"
                      data-testid="button-send-chat"
                    >
                      <Send className="w-4 h-4" />
                    </Button>
                  </div>
                </form>
              </motion.div>
            ) : (
              <motion.div
                key="email"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="bg-card rounded-2xl border border-border shadow-lg p-8"
              >
                <div className="text-center mb-6">
                  <Mail className="w-12 h-12 text-primary mx-auto mb-4" />
                  <h2 className="text-xl font-bold text-foreground mb-2">Send us a message</h2>
                  <p className="text-muted-foreground text-sm">
                    Email us at{" "}
                    <a href="mailto:support@locustwireless.com" className="text-primary hover:underline">
                      support@locustwireless.com
                    </a>{" "}
                    or use the form below.
                  </p>
                </div>

                <form onSubmit={handleEmailSubmit} className="space-y-4">
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Name *</Label>
                      <Input
                        id="name"
                        value={emailForm.name}
                        onChange={(e) => setEmailForm({ ...emailForm, name: e.target.value })}
                        placeholder="Your name"
                        data-testid="input-name"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">Email *</Label>
                      <Input
                        id="email"
                        type="email"
                        value={emailForm.email}
                        onChange={(e) => setEmailForm({ ...emailForm, email: e.target.value })}
                        placeholder="your@email.com"
                        data-testid="input-email-support"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="subject">Subject</Label>
                    <Input
                      id="subject"
                      value={emailForm.subject}
                      onChange={(e) => setEmailForm({ ...emailForm, subject: e.target.value })}
                      placeholder="What's this about?"
                      data-testid="input-subject"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="message">Message *</Label>
                    <Textarea
                      id="message"
                      value={emailForm.message}
                      onChange={(e) => setEmailForm({ ...emailForm, message: e.target.value })}
                      placeholder="Tell us how we can help..."
                      rows={5}
                      data-testid="input-message"
                    />
                  </div>
                  <Button
                    type="submit"
                    className="w-full rounded-xl h-12 bg-primary"
                    disabled={isSendingEmail}
                    data-testid="button-send-email"
                  >
                    {isSendingEmail ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Sending...
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4 mr-2" />
                        Send Message
                      </>
                    )}
                  </Button>
                </form>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Contact Info */}
          <div className="mt-12 text-center">
            <p className="text-muted-foreground text-sm">
              Need immediate assistance? Email us directly at{" "}
              <a href="mailto:support@locustwireless.com" className="text-primary hover:underline font-medium">
                support@locustwireless.com
              </a>
            </p>
          </div>
        </div>
      </main>
    </div>
  );
}
