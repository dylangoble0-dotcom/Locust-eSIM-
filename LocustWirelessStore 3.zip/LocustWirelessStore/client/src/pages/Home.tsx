import { Navbar } from "@/components/Navbar";
import { Hero } from "@/components/Hero";
import { PlanCard } from "@/components/PlanCard";
import { HowItWorks } from "@/components/HowItWorks";
import { Loader2 } from "lucide-react";
import logo from "@assets/IMG_3014_1764563357619.jpeg";
import { useQuery } from "@tanstack/react-query";
import { fetchPackages } from "@/lib/api";
import { Toaster } from "sonner";

export default function Home() {
  const { data: packages = [], isLoading } = useQuery({
    queryKey: ["packages"],
    queryFn: () => fetchPackages({ type: "BASE" }),
    staleTime: 5 * 60 * 1000,
  });

  // Filter to only US 30-day plans with 10GB to 50GB data
  const MIN_DATA_BYTES = 10 * 1024 * 1024 * 1024; // 10GB in bytes
  const MAX_DATA_BYTES = 50 * 1024 * 1024 * 1024; // 50GB in bytes
  
  const usPlans = packages
    .filter(p => 
      p.locationCode === 'US' && 
      p.duration === 30 &&
      p.volume >= MIN_DATA_BYTES && 
      p.volume <= MAX_DATA_BYTES
    )
    .sort((a, b) => a.volume - b.volume); // Sort by data amount

  return (
    <div className="min-h-screen bg-background font-sans">
      <Navbar />
      <Toaster position="top-center" richColors />
      
      <main>
        <Hero />
        
        <HowItWorks />

        <section className="py-24 container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-display font-bold text-foreground mb-4">Choose Your Plan</h2>
            <p className="text-muted-foreground max-w-xl mx-auto">Simple, affordable data plans. No contracts, no commitments.</p>
          </div>

          {isLoading ? (
            <div className="flex justify-center items-center py-20">
              <Loader2 className="h-10 w-10 animate-spin text-primary" />
              <span className="ml-4 text-muted-foreground">Loading plans...</span>
            </div>
          ) : usPlans.length > 0 ? (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8 max-w-4xl mx-auto">
              {usPlans.map((plan) => (
                <PlanCard key={plan.packageCode} plan={plan} showLocation={false} />
              ))}
            </div>
          ) : (
            <div className="text-center py-16 bg-muted/30 rounded-3xl">
              <p className="text-muted-foreground">No plans available at the moment.</p>
            </div>
          )}
        </section>

        {/* Trust/Social Proof Section */}
        <section className="py-20 bg-secondary text-secondary-foreground">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-display font-bold mb-12 text-white">What Our Customers Say</h2>
            <div className="grid md:grid-cols-3 gap-8">
              {[
                { quote: "Finally, affordable data without a contract. Saved so much compared to my old plan.", author: "Mike R." },
                { quote: "Easy to set up and the price is unbeatable. Perfect for my budget.", author: "Sarah T." },
                { quote: "No hidden fees, just straightforward pricing. Exactly what I needed.", author: "Chris P." }
              ].map((testimonial, i) => (
                <div key={i} className="bg-white/5 backdrop-blur-sm p-8 rounded-2xl border border-white/10">
                  <p className="text-lg italic mb-6 opacity-90 text-gray-200">"{testimonial.quote}"</p>
                  <div>
                    <div className="font-bold text-primary">{testimonial.author}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-background border-t border-border py-12">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center gap-6">
            <div className="flex items-center gap-3 font-display font-bold text-xl text-foreground">
              <div className="h-10 w-10 overflow-hidden rounded-lg border border-primary/20">
                <img src={logo} alt="Locust Wireless" className="h-full w-full object-cover" />
              </div>
              <span>LOCUST <span className="text-primary">WIRELESS</span></span>
            </div>
            <div className="text-sm text-muted-foreground">
              © 2025 Locust Wireless Inc. All rights reserved.
            </div>
            <div className="flex gap-6 text-sm font-medium text-muted-foreground">
              <a href="#" className="hover:text-primary">Privacy</a>
              <a href="#" className="hover:text-primary">Terms</a>
              <a href="#" className="hover:text-primary">Contact</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
