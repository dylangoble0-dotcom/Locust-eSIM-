import { useEffect } from "react";
import { Navbar } from "@/components/Navbar";
import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Loader2, Wifi, Calendar, Package, QrCode, Signal, Clock, Database } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Toaster } from "sonner";
import type { Order } from "@shared/schema";

interface DashboardData {
  orders: Order[];
  activeOrders: Order[];
  esimUsage: Record<string, {
    iccid: string;
    status: string;
    totalVolume?: number;
    usedVolume?: number;
    remainingVolume?: number;
    activationDate?: string;
    expiryDate?: string;
  }>;
}

export default function MyData() {
  const { user, isLoading: authLoading, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast.error("Please log in to view your dashboard");
      setTimeout(() => {
        setLocation("/login");
      }, 1000);
    }
  }, [authLoading, isAuthenticated, setLocation]);

  const { data: dashboardData, isLoading: dashboardLoading } = useQuery<DashboardData>({
    queryKey: ["/api/dashboard"],
    queryFn: async () => {
      const response = await fetch("/api/dashboard", { credentials: "include" });
      if (!response.ok) {
        throw new Error("Failed to fetch dashboard data");
      }
      return response.json();
    },
    enabled: isAuthenticated,
    retry: false,
    staleTime: 60 * 1000,
  });

  const completedOrders = dashboardData?.orders?.filter(o => o.status === "completed") || [];

  const formatPrice = (price: number) => ((price / 10000) * 2.5).toFixed(2);

  const formatData = (bytes: number | string | null | undefined) => {
    if (!bytes) return "--";
    const numBytes = typeof bytes === 'string' ? parseInt(bytes) : bytes;
    if (isNaN(numBytes)) return "--";
    const gb = numBytes / (1024 * 1024 * 1024);
    return gb >= 1 ? `${gb.toFixed(1)}GB` : `${(numBytes / (1024 * 1024)).toFixed(0)}MB`;
  };

  const getUsagePercent = (iccid: string, planVolume: string | null) => {
    const usage = dashboardData?.esimUsage?.[iccid];
    if (!usage?.usedVolume || !planVolume) return 0;
    const total = parseInt(planVolume);
    if (isNaN(total) || total === 0) return 0;
    return Math.min(100, (usage.usedVolume / total) * 100);
  };

  const getUsedData = (iccid: string) => {
    const usage = dashboardData?.esimUsage?.[iccid];
    return usage?.usedVolume ? formatData(usage.usedVolume) : "--";
  };

  const getRemainingData = (iccid: string, planVolume: string | null) => {
    const usage = dashboardData?.esimUsage?.[iccid];
    if (usage?.remainingVolume) return formatData(usage.remainingVolume);
    if (usage?.usedVolume && planVolume) {
      const total = parseInt(planVolume);
      const remaining = total - usage.usedVolume;
      return formatData(remaining > 0 ? remaining : 0);
    }
    return planVolume ? formatData(planVolume) : "--";
  };

  const getEsimStatus = (iccid: string) => {
    const usage = dashboardData?.esimUsage?.[iccid];
    if (!usage) return { label: "Active", color: "text-green-600", bg: "bg-green-500" };
    
    switch (usage.status?.toLowerCase()) {
      case "active":
      case "in_use":
        return { label: "Active", color: "text-green-600", bg: "bg-green-500" };
      case "expired":
        return { label: "Expired", color: "text-red-600", bg: "bg-red-500" };
      case "pending":
        return { label: "Pending", color: "text-yellow-600", bg: "bg-yellow-500" };
      default:
        return { label: "Ready", color: "text-blue-600", bg: "bg-blue-500" };
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-background font-sans">
        <Navbar />
        <div className="flex items-center justify-center h-[60vh]">
          <Loader2 className="h-10 w-10 animate-spin text-primary" />
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background font-sans">
        <Navbar />
        <Toaster position="top-center" richColors />
        <div className="flex flex-col items-center justify-center h-[60vh]">
          <Loader2 className="h-10 w-10 animate-spin text-primary mb-4" />
          <p className="text-muted-foreground">Redirecting to login...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background font-sans">
      <Navbar />
      <Toaster position="top-center" richColors />

      <main className="pt-28 pb-20">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            
            <div className="mb-8">
              <h1 className="text-3xl md:text-4xl font-display font-bold text-foreground mb-2">
                Dashboard
              </h1>
              <p className="text-muted-foreground">
                Welcome back, {user?.firstName || user?.email?.split('@')[0]}! Track your data plans and usage.
              </p>
            </div>

            {dashboardLoading ? (
              <div className="flex justify-center items-center py-20">
                <Loader2 className="h-10 w-10 animate-spin text-primary" />
                <span className="ml-4 text-muted-foreground">Loading your data...</span>
              </div>
            ) : completedOrders.length === 0 ? (
              <div className="text-center py-16 bg-muted/30 rounded-3xl">
                <Package className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-xl font-bold text-foreground mb-2">No Active Plans</h3>
                <p className="text-muted-foreground mb-6">You haven't purchased any data plans yet. Get started with affordable, no-contract data!</p>
                <Button 
                  className="bg-primary text-primary-foreground hover:bg-primary/90"
                  onClick={() => setLocation("/plans")}
                  data-testid="button-browse-plans"
                >
                  Browse Plans
                </Button>
              </div>
            ) : (
              <div className="space-y-6">
                <div className="mb-6">
                  <h2 className="text-lg font-semibold text-foreground mb-2">Your Active Plans</h2>
                  <p className="text-sm text-muted-foreground">
                    {completedOrders.length} plan{completedOrders.length !== 1 ? 's' : ''} purchased
                  </p>
                </div>

                {completedOrders.map((order) => {
                  const iccid = order.iccids?.[0] || '';
                  const status = getEsimStatus(iccid);
                  const usagePercent = getUsagePercent(iccid, order.planVolumeBytes);

                  return (
                    <div 
                      key={order.id} 
                      className="bg-card rounded-2xl border border-border p-6 shadow-sm hover:shadow-md transition-shadow"
                      data-testid={`order-card-${order.orderNo}`}
                    >
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
                        <div>
                          <h3 className="text-xl font-bold text-foreground">{order.packageName}</h3>
                          <p className="text-sm text-muted-foreground">Order: {order.orderNo}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className={`w-2 h-2 rounded-full ${status.bg}`}></div>
                          <span className={`text-sm font-medium ${status.color}`}>{status.label}</span>
                        </div>
                      </div>

                      {order.planVolumeBytes && (
                        <div className="mb-6 bg-muted/30 rounded-xl p-4">
                          <div className="flex justify-between items-center mb-2">
                            <span className="text-sm text-muted-foreground">Data Usage</span>
                            <span className="text-sm font-medium text-foreground">
                              {getUsedData(iccid)} / {formatData(order.planVolumeBytes)}
                            </span>
                          </div>
                          <Progress value={usagePercent} className="h-3" />
                          <div className="flex justify-between items-center mt-2">
                            <span className="text-xs text-muted-foreground">
                              {usagePercent.toFixed(0)}% used
                            </span>
                            <span className="text-xs text-primary font-medium">
                              {getRemainingData(iccid, order.planVolumeBytes)} remaining
                            </span>
                          </div>
                        </div>
                      )}

                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                        <div className="bg-muted/50 rounded-xl p-4">
                          <div className="flex items-center gap-2 text-muted-foreground mb-1">
                            <Database className="h-4 w-4" />
                            <span className="text-xs">Total Data</span>
                          </div>
                          <div className="font-bold text-foreground">
                            {formatData(order.planVolumeBytes)}
                          </div>
                        </div>
                        <div className="bg-muted/50 rounded-xl p-4">
                          <div className="flex items-center gap-2 text-muted-foreground mb-1">
                            <Clock className="h-4 w-4" />
                            <span className="text-xs">Duration</span>
                          </div>
                          <div className="font-bold text-foreground">
                            {order.planDurationDays ? `${order.planDurationDays} days` : "--"}
                          </div>
                        </div>
                        <div className="bg-muted/50 rounded-xl p-4">
                          <div className="flex items-center gap-2 text-muted-foreground mb-1">
                            <Signal className="h-4 w-4" />
                            <span className="text-xs">Network</span>
                          </div>
                          <div className="font-bold text-foreground text-sm">
                            {order.networkSpeed || "4G/5G"}
                          </div>
                        </div>
                        <div className="bg-muted/50 rounded-xl p-4">
                          <div className="flex items-center gap-2 text-muted-foreground mb-1">
                            <Calendar className="h-4 w-4" />
                            <span className="text-xs">Purchased</span>
                          </div>
                          <div className="font-bold text-foreground">
                            {new Date(order.createdAt).toLocaleDateString()}
                          </div>
                        </div>
                      </div>

                      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 pt-4 border-t border-border">
                        <div>
                          {order.iccids && order.iccids.length > 0 && (
                            <div>
                              <p className="text-xs text-muted-foreground mb-1">ICCID:</p>
                              <code className="text-xs bg-muted px-2 py-1 rounded font-mono">
                                {order.iccids[0]}
                              </code>
                            </div>
                          )}
                        </div>
                        <div className="flex items-center gap-4">
                          <span className="text-lg font-bold text-primary">${formatPrice(order.totalAmount)}</span>
                          {order.qrCodes && order.qrCodes.length > 0 && (
                            <div className="flex items-center gap-1 text-sm text-muted-foreground">
                              <QrCode className="h-4 w-4" />
                              <span>QR sent</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}

                <div className="text-center pt-6">
                  <Button 
                    variant="outline"
                    onClick={() => setLocation("/plans")}
                    data-testid="button-add-plan"
                  >
                    Add Another Plan
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
