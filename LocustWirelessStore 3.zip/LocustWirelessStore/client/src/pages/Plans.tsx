import { Navbar } from "@/components/Navbar";
import { PlanCard } from "@/components/PlanCard";
import { Loader2 } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { fetchPackages } from "@/lib/api";
import { Toaster } from "sonner";

export default function Plans() {
  const { data: packages = [], isLoading, error } = useQuery({
    queryKey: ["packages"],
    queryFn: () => fetchPackages({ type: "BASE" }),
    staleTime: 5 * 60 * 1000,
  });

  // Filter to only US 30-day plans with 10GB to 50GB data
  const MIN_DATA_BYTES = 10 * 1024 * 1024 * 1024; // 10GB in bytes
  const MAX_DATA_BYTES = 50 * 1024 * 1024 * 1024; // 50GB in bytes
  
  const usPlans = packages
    .filter(p => 
      p.locationCode === 'US' && 
      p.duration === 30 &&
      p.volume >= MIN_DATA_BYTES && 
      p.volume <= MAX_DATA_BYTES
    )
    .sort((a, b) => a.volume - b.volume); // Sort by data amount

  return (
    <div className="min-h-screen bg-background font-sans">
      <Navbar />
      <Toaster position="top-center" richColors />
      
      <main className="pt-32 pb-20">
        <div className="container mx-auto px-4">
          
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h1 className="text-4xl md:text-5xl font-display font-bold text-foreground mb-6">Our Plans</h1>
            <p className="text-muted-foreground text-lg">No contracts, no hidden fees. Choose the plan that works for you.</p>
          </div>

          {isLoading ? (
            <div className="flex justify-center items-center py-20">
              <Loader2 className="h-10 w-10 animate-spin text-primary" />
              <span className="ml-4 text-muted-foreground">Loading plans...</span>
            </div>
          ) : error ? (
            <div className="text-center py-20 bg-destructive/10 rounded-3xl">
              <p className="text-lg text-destructive">Failed to load plans. Please try again later.</p>
              <p className="text-sm text-muted-foreground mt-2">{(error as Error).message}</p>
            </div>
          ) : usPlans.length > 0 ? (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8 max-w-4xl mx-auto">
              {usPlans.map((plan) => (
                <PlanCard key={plan.packageCode} plan={plan} showLocation={false} />
              ))}
            </div>
          ) : (
            <div className="text-center py-20 bg-muted/30 rounded-3xl">
              <p className="text-lg text-muted-foreground">No plans available at the moment.</p>
            </div>
          )}
          
        </div>
      </main>
    </div>
  );
}
