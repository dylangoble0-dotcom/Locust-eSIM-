import { Package, ApiResponse, PackageListResponse } from "./api-types";

const API_BASE = "/api";

export async function fetchPackages(filters: {
  locationCode?: string;
  type?: "BASE" | "TOPUP";
} = {}): Promise<Package[]> {
  const response = await fetch(`${API_BASE}/packages`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(filters),
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || "Failed to fetch packages");
  }

  const data = await response.json();
  return data.packageList || [];
}

export interface CreateOrderRequest {
  email: string;
  packageCode: string;
  quantity?: number;
}

export interface Order {
  id: string;
  orderNo: string;
  email: string;
  packageCode: string;
  packageName: string;
  quantity: number;
  price: number;
  totalAmount: number;
  status: string;
  iccids: string[] | null;
  qrCodes: string[] | null;
  createdAt: string;
  updatedAt: string;
}

export async function createOrder(request: CreateOrderRequest): Promise<Order> {
  const response = await fetch(`${API_BASE}/orders`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(request),
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || "Failed to create order");
  }

  return response.json();
}

export async function getOrdersByEmail(email: string): Promise<Order[]> {
  const response = await fetch(`${API_BASE}/orders/${encodeURIComponent(email)}`);

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || "Failed to fetch orders");
  }

  return response.json();
}

export async function getOrderByOrderNo(orderNo: string): Promise<Order> {
  const response = await fetch(`${API_BASE}/order/${encodeURIComponent(orderNo)}`);

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || "Failed to fetch order");
  }

  return response.json();
}
