import { Package } from "./api-types";

export const mockPackages: Package[] = [
  {
    packageCode: "CKH491",
    slug: "NA-3_1_7",
    name: "North America 1GB 7Days",
    price: 57000, // $5.70
    currencyCode: "USD",
    volume: 1073741824, // 1 GB
    smsStatus: 1,
    dataType: 1,
    unusedValidTime: 180,
    duration: 7,
    durationUnit: "DAY",
    location: "MX,US,CA",
    description: "North America 1GB 7Days",
    activeType: 2,
    favorite: true,
    retailPrice: 114000,
    speed: "4G/5G",
    locationNetworkList: [
      {
        locationName: "United States",
        locationLogo: "/img/flags/us.png",
        operatorList: [{ operatorName: "Verizon", networkType: "5G" }, { operatorName: "T-Mobile", networkType: "5G" }]
      },
      {
        locationName: "Canada",
        locationLogo: "/img/flags/ca.png",
        operatorList: [{ operatorName: "Rogers", networkType: "5G" }]
      }
    ]
  },
  {
    packageCode: "EU20_30",
    slug: "EU-20_30",
    name: "Europe 20GB 30Days",
    price: 250000, // $25.00
    currencyCode: "USD",
    volume: 21474836480, // 20 GB
    smsStatus: 0,
    dataType: 1,
    unusedValidTime: 180,
    duration: 30,
    durationUnit: "DAY",
    location: "FR,DE,IT,ES,UK,NL,BE,CH,AT,PT",
    description: "Europe Regional High Speed",
    activeType: 2,
    favorite: true,
    retailPrice: 350000,
    speed: "4G/5G",
    locationNetworkList: [
      {
        locationName: "France",
        locationLogo: "/img/flags/fr.png",
        operatorList: [{ operatorName: "Orange", networkType: "5G" }]
      }
    ]
  },
  {
    packageCode: "JP05_15",
    slug: "JP-5_15",
    name: "Japan 5GB 15Days",
    price: 120000, // $12.00
    currencyCode: "USD",
    volume: 5368709120, // 5 GB
    smsStatus: 0,
    dataType: 1,
    unusedValidTime: 180,
    duration: 15,
    durationUnit: "DAY",
    location: "JP",
    description: "Japan Travel Data",
    activeType: 2,
    favorite: false,
    retailPrice: 180000,
    speed: "4G/5G",
    locationNetworkList: [
      {
        locationName: "Japan",
        locationLogo: "/img/flags/jp.png",
        operatorList: [{ operatorName: "Softbank", networkType: "5G" }, { operatorName: "Docomo", networkType: "4G" }]
      }
    ]
  },
  {
    packageCode: "TH_UNL_8",
    slug: "TH-UNL_8",
    name: "Thailand Unlimited 8Days",
    price: 95000, // $9.50
    currencyCode: "USD",
    volume: -1, // Unlimited representation
    smsStatus: 1,
    dataType: 4, // Daily Unlimited
    unusedValidTime: 90,
    duration: 8,
    durationUnit: "DAY",
    location: "TH",
    description: "Thailand Tourist Sim",
    activeType: 1,
    favorite: true,
    retailPrice: 150000,
    speed: "5G",
    locationNetworkList: [
      {
        locationName: "Thailand",
        locationLogo: "/img/flags/th.png",
        operatorList: [{ operatorName: "AIS", networkType: "5G" }]
      }
    ]
  },
  {
    packageCode: "GL_1_7",
    slug: "GL-1_7",
    name: "Global 1GB 7Days",
    price: 90000, // $9.00
    currencyCode: "USD",
    volume: 1073741824,
    smsStatus: 0,
    dataType: 1,
    unusedValidTime: 365,
    duration: 7,
    durationUnit: "DAY",
    location: "US,UK,FR,DE,JP,CN,HK,SG,AU,NZ,ZA,BR", // Truncated for brevity
    description: "Global Travel Data",
    activeType: 2,
    favorite: false,
    retailPrice: 120000,
    speed: "4G",
    locationNetworkList: []
  }
];
