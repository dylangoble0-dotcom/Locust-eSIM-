export interface Operator {
  operatorName: string;
  networkType: string;
}

export interface LocationNetwork {
  locationName: string;
  locationLogo: string;
  operatorList: Operator[];
}

export interface Package {
  packageCode: string;
  slug: string;
  name: string;
  price: number; // Value * 10,000 (10000 = $1.00)
  currencyCode: string;
  volume: number; // Bytes
  smsStatus: number; // 0: Not supported, 1: API+Mobile, 2: API only
  dataType: number; // 1: Total, 2: Daily Limit (Speed Reduced), 3: Daily Limit (Cut-off), 4: Daily Unlimited
  unusedValidTime: number; // Time till package invalid (days?)
  duration: number; // Plan validity period
  durationUnit: string; // "DAY"
  location: string; // Comma separated ISO codes
  locationCode: string; // ISO code for the package
  description: string;
  activeType: number; // 1: First installation, 2: First network connection
  favorite: boolean;
  retailPrice: number;
  speed: string; // "3G/4G"
  locationNetworkList: LocationNetwork[];
  ipExport?: string;
  supportTopUpType?: boolean;
}

export interface ApiResponse<T> {
  success: boolean;
  errorCode: string | null;
  errorMessage: string | null;
  obj: T;
}

export interface PackageListResponse {
  packageList: Package[];
}
