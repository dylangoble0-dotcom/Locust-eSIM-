import { ScanLine, CreditCard, Wifi } from "lucide-react";
import { motion } from "framer-motion";

export function HowItWorks() {
  const steps = [
    {
      icon: <CreditCard className="h-8 w-8 text-primary" />,
      title: "Pick a Plan",
      description: "Choose an affordable 30-day plan that fits your budget. No contracts, cancel anytime."
    },
    {
      icon: <ScanLine className="h-8 w-8 text-primary" />,
      title: "Scan QR Code",
      description: "Receive your eSIM instantly via email and scan the QR code to install on your phone."
    },
    {
      icon: <Wifi className="h-8 w-8 text-primary" />,
      title: "Get Connected",
      description: "Turn on your eSIM and enjoy reliable data without breaking the bank."
    }
  ];

  return (
    <section className="py-24 bg-muted/30 border-y border-border/50">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-display font-bold text-primary mb-4">Simple as 1-2-3</h2>
          <p className="text-muted-foreground">Get connected in minutes. No contracts, no hassle, just affordable data when you need it.</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 relative">
          {/* Connecting Line (Desktop) */}
          <div className="hidden md:block absolute top-12 left-1/6 right-1/6 h-0.5 bg-gradient-to-r from-transparent via-primary/20 to-transparent z-0"></div>

          {steps.map((step, index) => (
            <motion.div 
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.2 }}
              className="relative z-10 flex flex-col items-center text-center group"
            >
              <div className="w-24 h-24 rounded-full bg-white border-4 border-muted flex items-center justify-center shadow-sm mb-6 group-hover:border-primary/30 group-hover:scale-110 transition-all duration-300">
                {step.icon}
              </div>
              <h3 className="text-xl font-bold text-primary mb-3">{step.title}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed max-w-xs">
                {step.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
