import { motion } from "framer-motion";
import { Check, ArrowRight, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Package } from "@/lib/api-types";
import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import { createOrder } from "@/lib/api";
import { toast } from "sonner";

interface PlanCardProps {
  plan: Package;
  showLocation?: boolean;
}

export function PlanCard({ plan, showLocation = true }: PlanCardProps) {
  const [isBuying, setIsBuying] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [email, setEmail] = useState("");

  const MARKUP_MULTIPLIER = 2.5; // 150% markup (100% + 150% = 250% = 2.5x)
  const formatPrice = (price: number) => ((price / 10000) * MARKUP_MULTIPLIER).toFixed(2);
  
  const formatData = (volume: number, dataType: number) => {
    if (dataType === 4 || volume === -1) return "Unlimited";
    const gb = volume / (1024 * 1024 * 1024);
    return gb >= 1 ? `${gb.toFixed(0)}GB` : `${(volume / (1024 * 1024)).toFixed(0)}MB`;
  };

  const getFlag = (countryCode: string) => {
    const code = countryCode.split(',')[0].toUpperCase();
    if (code === '!GL') return '🌍';
    if (code === '!RG') return '🌐';
    try {
      return code.replace(/./g, char => String.fromCodePoint(char.charCodeAt(0) + 127397));
    } catch {
      return '🌐';
    }
  };

  const handleBuy = async () => {
    if (!email || !email.includes('@')) {
      toast.error("Please enter a valid email address");
      return;
    }

    setIsBuying(true);
    try {
      const order = await createOrder({
        email,
        packageCode: plan.packageCode,
        quantity: 1,
      });
      
      setIsOpen(false);
      setEmail("");
      
      toast.success(`Order ${order.orderNo} created!`, {
        description: order.status === "completed" 
          ? "Your eSIM QR code has been sent to your email."
          : "Your order is being processed. Check your email shortly.",
        duration: 5000,
      });
    } catch (error: any) {
      toast.error("Order failed", {
        description: error.message || "Please try again later.",
      });
    } finally {
      setIsBuying(false);
    }
  };

  const regionNames = new Intl.DisplayNames(['en'], { type: 'region' });
  const getCountryName = (code: string) => {
    const firstCode = code.split(',')[0];
    if (firstCode === '!GL') return 'Global';
    if (firstCode === '!RG') return 'Regional';
    try {
      return regionNames.of(firstCode) || code;
    } catch {
      return code;
    }
  };

  const getDataLabel = (volume: number, dataType: number) => {
    if (dataType === 4 || volume === -1) return "Unlimited Plan";
    const gb = volume / (1024 * 1024 * 1024);
    return `${gb.toFixed(0)}GB Plan`;
  };

  const features = [
    "30 Day Validity",
    plan.speed,
    plan.supportTopUpType ? "Top-up Available" : "Single Use",
    "Hotspot Included"
  ];

  // Feature the middle-tier plan (around 20-30GB)
  const dataGB = plan.volume / (1024 * 1024 * 1024);
  const isFeatured = dataGB >= 20 && dataGB <= 30;

  return (
    <motion.div 
      whileHover={{ y: -5 }}
      className={`relative group rounded-2xl border ${isFeatured ? 'border-primary/50 shadow-xl shadow-primary/10' : 'border-border hover:border-primary/30 shadow-sm hover:shadow-lg'} bg-card transition-all duration-300 overflow-hidden flex flex-col h-full`}
      data-testid={`card-plan-${plan.packageCode}`}
    >
      {isFeatured && (
        <div className="absolute top-0 right-0 bg-primary text-primary-foreground text-[10px] font-bold px-3 py-1 rounded-bl-xl uppercase tracking-wider z-10">
          Most Popular
        </div>
      )}

      <div className="p-6 flex-1">
        <div className="mb-4">
          {showLocation && (
            <div className="flex items-center gap-3 mb-3">
              <div className="text-3xl">{getFlag(plan.location)}</div>
              <p className="text-xs text-muted-foreground font-medium uppercase tracking-wider">
                {getCountryName(plan.location)}
              </p>
            </div>
          )}
          <h3 className="font-display font-bold text-xl text-foreground leading-tight" data-testid={`text-plan-name-${plan.packageCode}`}>
            {getDataLabel(plan.volume, plan.dataType)}
          </h3>
        </div>

        <div className="mb-6">
          <div className="flex items-baseline gap-1">
            <span className="text-4xl font-bold text-primary" data-testid={`text-price-${plan.packageCode}`}>${formatPrice(plan.price)}</span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-6 p-4 bg-muted/50 rounded-xl border border-border/50">
          <div>
            <p className="text-xs text-muted-foreground mb-1">Data</p>
            <p className="font-bold text-foreground text-lg" data-testid={`text-data-${plan.packageCode}`}>{formatData(plan.volume, plan.dataType)}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground mb-1">Validity</p>
            <p className="font-bold text-foreground text-lg">{plan.duration} Days</p>
          </div>
        </div>

        <ul className="space-y-2.5 mb-6">
          {features.map((feature, i) => (
            <li key={i} className="flex items-center gap-2 text-sm text-muted-foreground">
              <Check className="h-4 w-4 text-primary flex-shrink-0" />
              <span>{feature}</span>
            </li>
          ))}
        </ul>
      </div>

      <div className="p-6 pt-0 mt-auto">
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogTrigger asChild>
            <Button 
              className={`w-full rounded-xl h-12 font-medium transition-all ${isFeatured ? 'bg-primary text-primary-foreground hover:bg-primary/90' : 'bg-transparent text-primary border-2 border-primary/10 hover:border-primary hover:bg-primary/5'}`}
              data-testid={`button-buy-${plan.packageCode}`}
            >
              Choose Plan <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Complete Your Purchase</DialogTitle>
              <DialogDescription>
                Enter your email to receive the eSIM QR code for <strong>{getDataLabel(plan.volume, plan.dataType)}</strong>.
              </DialogDescription>
            </DialogHeader>
            <div className="py-4 space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email Address</Label>
                <Input 
                  id="email" 
                  type="email" 
                  placeholder="your@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  data-testid="input-email"
                />
              </div>
              <div className="flex justify-between items-center py-2 border-b border-border">
                <span className="text-muted-foreground">Price</span>
                <span className="font-bold">${formatPrice(plan.price)}</span>
              </div>
              <div className="flex justify-between items-center py-2 border-b border-border">
                <span className="text-muted-foreground">Data</span>
                <span className="font-bold">{formatData(plan.volume, plan.dataType)}</span>
              </div>
              <div className="flex justify-between items-center py-2 border-b border-border">
                <span className="text-muted-foreground">Validity</span>
                <span className="font-bold">{plan.duration} Days</span>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsOpen(false)} disabled={isBuying}>Cancel</Button>
              <Button onClick={handleBuy} disabled={isBuying || !email} className="bg-primary text-primary-foreground" data-testid="button-confirm-order">
                {isBuying ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Processing...
                  </>
                ) : (
                  "Confirm & Pay"
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </motion.div>
  );
}
